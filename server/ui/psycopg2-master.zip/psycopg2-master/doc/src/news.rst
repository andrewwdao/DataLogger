.. index::
    single: Release notes
    single: News

Release notes
=============

.. include:: ../../NEWS
